# Layout Rule Management

This directory (`.claude/ppt-layout/rules/`) holds the saved layout rules for this
project. It is maintained by the `ppt-layout` skill and is safe to edit by hand and to
commit to version control.

## Files

| File | Purpose |
|------|---------|
| `README.md` | This guide. |
| `rule-assignments.md` | Maps each rule to a deck and to the slides it applies to. |
| `<rule-name>.md` | One named rule: what to change and to what values. |

A rule file describes **what** the layout should be. The assignments file describes
**where** it applies. Keeping them separate lets one rule be reused across decks and
slide selections.

## When a rule is saved

Only when the user asks to save, name, or reuse it. One-off instructions are applied
to the deck and not written here.

## Creating a rule

1. Choose a unique name in lowercase kebab-case, e.g. `title-left-32pt`.
2. Copy `templates/rule-template.md` from the skill to `<rule-name>.md` and fill in
   every field. Use measurable values (inches, points, hex colors), not adjectives.
3. Add one row per deck to `rule-assignments.md`.
4. Validate the slide numbers (see below).

## Scopes

| Scope | `Slides` value | Tier |
|-------|----------------|------|
| `deck` | `all` | 3 |
| `range` | `3-8` (inclusive) or a set `2, 4, 6` | 2 |
| `slide` | a single number, `5` | 1 |

A set may mix forms: `2, 4, 6-9`. A set or range that resolves to exactly one slide is
still tier 2; use scope `slide` to make it a tier-1 exception.

## Precedence and conflicts

Tier 1 beats tier 2 beats tier 3 beats the deck's existing layout defaults.

- Two rules conflict only when they set the **same property** on the **same target**
  on the **same slide**. Different properties never conflict.
- The more specific rule replaces just the conflicting property. All other properties
  of the broader rule remain in force.
- Same tier, same property, same slide: the rule covering fewer slides wins. If both
  cover the same number of slides, the conflict is unresolved; the skill asks the
  user and records the decision in the `Overrides` column.
- Record known overrides in `rule-assignments.md` so the outcome is visible without
  re-deriving it.

Example for slide 5 of a 12-slide deck:

| Rule | Scope | Property set | Result on slide 5 |
|------|-------|--------------|-------------------|
| `title-left` | deck | title alignment = left | applies |
| `two-column` | range 3-8 | body columns = 2; chart in right column | columns apply; chart placement overridden |
| `chart-below-text` | slide 5 | chart position = below text | applies |

## Managing ranges and single-slide exceptions

- To exempt one slide from a range rule, add a `slide`-scope rule for that slide that
  sets the differing property. Do not split the range into two ranges.
- To exempt a slide from a rule entirely, list it in the assignment's `Excluded`
  column. The rule then sets nothing on that slide and lower tiers apply.
- To extend or shrink a range, edit the `Slides` value in the assignments file and
  update `Validated` and `Slide count`.
- To retire a rule without deleting it, set its `Status` to `inactive`.

## Slide number validation

Checked every time rules are saved or applied:

1. Slide numbers are integers, 1-based, in on-screen order. Hidden slides count.
2. Every number satisfies `1 <= n <= slide count`.
3. For a range `a-b`, `a <= b`.
4. `Excluded` slides must fall inside the rule's `Slides`.
5. The deck's current slide count must equal the `Slide count` recorded in the
   assignment row. If it differs, slides were added, removed, or reordered: the skill
   stops, shows the affected rows, and asks the user to confirm or correct the slide
   numbers before applying any `range` or `slide` rule. `deck` rules are unaffected.

Invalid numbers are never silently clamped or skipped; they are reported.

## Editing and removing

- Change values in the rule file; bump `updated`.
- Change where a rule applies in `rule-assignments.md` only.
- Remove a rule by deleting its file **and** all of its assignment rows. The skill
  does this only on explicit request.
