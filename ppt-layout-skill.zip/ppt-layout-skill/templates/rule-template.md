---
name: rule-name-in-kebab-case
summary: One sentence describing what this rule enforces.
default_scope: deck          # deck | range | slide - the scope this rule is normally used at
created: YYYY-MM-DD
updated: YYYY-MM-DD
---

# rule-name-in-kebab-case

<!--
Copy this file to .claude/ppt-layout/rules/<rule-name>.md and replace every value.
The file name must match `name`. Where the rule applies is recorded in
rule-assignments.md, not here. Delete rows and sections that do not apply; do not
leave placeholder values in a saved rule.

Filled-in example of the sections below, for a rule named `title-left-32pt`:

  Intent:      Every slide title starts at the same point and uses the same size.
  Target:      Title placeholder
  Properties:  left = 0.60 in | top = 0.40 in | width = 12.10 in |
               horizontal alignment = left | font size = 32 pt
  Tolerance:   0.02 in
  Constraints: Do not reduce font size below 28 pt to fit; report overflow instead.
-->

## Intent

What the rule is for, in the user's own words where possible.

## Target

Which objects the rule applies to. Be specific enough to select them reliably.

| Field | Value |
|-------|-------|
| Object type | title / body text / picture / chart / table / footer / all content |
| Selector | placeholder type, shape name pattern, or "all pictures" |
| Excludes | objects to leave alone, e.g. background images, logos |

## Properties

One row per property. Use measurable values: inches or cm for geometry, pt for type,
hex for color. A property not listed here is not governed by this rule.

| Property | Value | Notes |
|----------|-------|-------|
| left | 0.60 in | distance from the slide's left edge |
| top | 0.40 in | distance from the slide's top edge |
| width | 12.10 in | |
| height | (unset) | leave as-is |
| horizontal alignment | left | left / center / right / justify |
| vertical anchor | top | top / middle / bottom |
| font family | (unset) | |
| font size | 32 pt | |
| font color | (unset) | hex, e.g. #1F2937 |
| spacing to next object | 0.30 in | |
| columns | (unset) | count and gutter, e.g. 2 columns, 0.40 in gutter |
| aspect ratio | preserve | for pictures and charts |

## Tolerance

Maximum deviation still counted as compliant. Default: 0.02 in for geometry, 0 pt for
font size.

## Constraints

Limits the skill must respect while applying this rule.

- Minimum font size: 12 pt body, 18 pt title.
- Never crop pictures or change chart data to make content fit.
- If the rule cannot be met without breaking a constraint, report it instead of
  forcing the change.

## Verification

How to confirm the rule holds after applying it.

- Compare each target's bounds to the values above within tolerance.
- Confirm no target extends past the slide edge or overlaps another object.
- Confirm text content is unchanged.

## Notes

Decisions, exceptions, and the reasoning behind chosen values.
