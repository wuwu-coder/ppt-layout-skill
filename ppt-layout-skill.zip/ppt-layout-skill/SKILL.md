---
name: ppt-layout
description: Manage PowerPoint (.pptx) layout consistency using natural-language rules scoped to the whole deck, a slide range, or a single slide. Use when the user wants to align, unify, or audit slide layout (title position, margins, fonts, image sizes, columns), check for text overflow, overlapping or off-slide objects, or save, list, and reuse named layout rules.
argument-hint: "[path/to/deck.pptx] [layout instruction]"
---

# ppt-layout

Check, modify, and verify the layout of a PowerPoint deck according to rules the user
states in natural language. Rules have a scope (deck, slide range, single slide) and a
fixed precedence. Rules can be one-off or saved by name for reuse.

Arguments passed to the skill: `$ARGUMENTS`

## Core principles

1. **Layout only.** Change position, size, alignment, spacing, and text formatting.
   Never delete content, reword text, alter chart data, or change facts, figures, or
   citations unless the user explicitly asks.
2. **Be truthful about capability.** Only report a check as done if a tool actually
   performed it. If something could not be inspected or modified, say so explicitly.
3. **Do not persist uninvited.** A one-off instruction is applied and then forgotten.
   Save a rule only when the user asks to save, name, or reuse it.
4. **Work on a copy.** Write changes to a new file (`<name>.layout.pptx`) unless the
   user asks to overwrite the original.
5. **Confirm major conflicts.** If applying a rule would force content off the slide,
   shrink text below a readable size, or contradict another rule at the same
   precedence tier, stop and ask before changing anything.

## Scopes and precedence

| Tier | Scope | Example | Wins over |
|------|-------|---------|-----------|
| 1 (highest) | Single slide | "slide 5" | everything below |
| 2 | Slide range or slide set | "slides 3-8", "slides 2, 4, 6" | deck, defaults |
| 3 | Deck-wide | "the whole deck" | defaults |
| 4 (lowest) | Existing layout defaults | slide master / layout | nothing |

Resolution rules:

- A more specific rule overrides a broader one **only for the properties that actually
  conflict**. Every non-conflicting property of the broader rule still applies.
- Ranges are inclusive at both ends: "slides 3-8" means 3, 4, 5, 6, 7, 8.
- Two rules in the same tier that conflict on the same property and slide: the one
  covering fewer slides wins. If they cover the same number of slides, ask the user.

Worked example:

- Deck: all titles left-aligned.
- Slides 3-8: content uses a two-column layout.
- Slide 5: the chart sits below the text.

Slide 5 ends up with a left-aligned title (deck rule, no conflict), the two-column
treatment for everything the slide rule does not address (range rule), and the chart
placed below the text (slide rule, overriding only the chart position that the
two-column rule would otherwise set).

To resolve the effective rules for a slide, build a property map: start with deck
rules, overlay range rules, then overlay single-slide rules, replacing a property only
when the more specific rule sets that same property on that same target.

## Workflow

Follow these steps in order on every run.

### 1. Identify the deck

- Locate the `.pptx` file from the arguments or the conversation. If several
  candidates exist and it is unclear which is meant, ask.
- Open it and record: slide count, slide size (width x height), and for each slide its
  layout name and a list of shapes (name, type, placeholder type, position, size).
- Slide numbers are 1-based and follow the on-screen order, including hidden slides.

### 2. Understand the requested scope

Classify the request as one or more of: apply a rule, check consistency, save a rule,
list rules, edit or remove a rule. Identify which slides each part refers to.

### 3. Translate natural language into explicit rules

Convert every instruction into concrete, measurable properties. Use
`templates/rule-template.md` as the shape of a rule. For example:

| User says | Explicit rule |
|-----------|---------------|
| "Unify the title position, font size, and side margins across the deck" | scope: deck; target: title; left = 0.6 in, top = 0.4 in, font size = 32 pt; target: all content; left margin = right margin = 0.6 in |
| "Make slides 3 to 8 two-column" | scope: range 3-8; target: body content; two columns, equal width, 0.4 in gutter |
| "Slide 5 is an exception, put the chart below the text" | scope: slide 5; target: chart; position below body text, full content width |
| "Make the images on slides 2, 4, and 6 the same size" | scope: set {2, 4, 6}; target: pictures; width and height equal, aspect ratio preserved |

When the user gives no number ("unify the title position"), derive the target value
from the deck itself: use the most common existing value, state which value was
chosen and why, and proceed. Ask only if the existing values have no clear majority.

### 4. Confirm scope and precedence

State each rule's scope and tier. Load any saved rules from
`.claude/ppt-layout/rules/` that are assigned to this deck (see
`references/rules-readme.md`) and include them in the resolution.

### 5. Validate slide numbers and detect conflicts

- Every slide number must be an integer between 1 and the slide count.
- Range start must be less than or equal to range end.
- Reject or ask about anything out of bounds; never silently clamp a range or skip a
  missing slide.
- Report every conflict found between rules and how precedence resolves it.
- If the slide count differs from the count recorded in the assignments file, slides
  were probably added, removed, or reordered. Flag this and ask the user to confirm
  the saved slide numbers before applying saved range or single-slide rules.

### 6. Apply the changes

Use whichever tool is available, in this order of preference:

1. A dedicated PowerPoint skill or tool present in the session.
2. `python-pptx` through a script (`pip install python-pptx` if missing and allowed).
3. If no tool can edit the file, do not pretend. Produce the explicit rule list and
   per-slide instructions for the user to apply manually, and say that nothing was
   modified.

Prefer the least invasive change: move and resize shapes before changing font size;
change font size before anything that would affect content.

### 7. Verify

Re-open the saved file and re-run the checks below on every modified slide. Where a
renderer is available (for example LibreOffice converting slides to images), render the
changed slides and inspect them visually. Compare text content before and after to
confirm nothing was lost or reworded.

### 8. Report

Always finish with:

- **Slides modified** - list of slide numbers, and the output file path.
- **Rules applied** - each rule, its scope, and its tier.
- **Conflicts** - what conflicted and which rule won.
- **Check results** - findings per slide, with the check that produced each one.
- **Not checked / not possible** - every check that could not be performed and why.
- **Unresolved issues** - anything still needing the user's decision.

## Layout checks

Run those that the available tools support; list the rest under "Not checked".

| Check | What to look for | Method with python-pptx |
|-------|------------------|-------------------------|
| Alignment | Titles, text boxes, pictures, charts sharing a left/top/center line | Compare shape `left`, `top`, `width`, `height` across slides |
| Margins and spacing | Distance to slide edges; gaps between objects | Compute from shape bounds and slide size |
| Off-slide content | Any shape extending past the slide boundary | Bounds outside `0..slide_width` / `0..slide_height` |
| Overlap | Unintended intersection of bounding boxes | Pairwise rectangle intersection; ignore backgrounds, groups' own children, and deliberate overlays such as captions on images |
| Typography | Font family, size, color, and hierarchy consistency | Read run, paragraph, and placeholder formatting; a value of `None` means inherited from the layout or master, so report it as "inherited", not as a specific value |
| Text overflow / clipping | Text exceeding its box | **Estimate only**: compare text length, font size, and box size, and read the autofit setting. Exact overflow needs a rendered image |
| Repeated elements | Logos, footers, page numbers, and recurring images with the same size and position | Group shapes by name or type and compare bounds |
| Legibility after change | Text still readable, meaning preserved | Minimum font size threshold (default 12 pt body, 18 pt title); text diff before vs. after |

Default tolerance for "same position" or "same size" is 0.02 in (about 18,288 EMU)
unless a rule specifies otherwise.

Known limits to state when relevant: python-pptx does not render slides, so true text
overflow, actual line wrapping, and visual clarity cannot be confirmed without a
renderer; SmartArt internals and embedded chart layouts are not inspectable in detail.

## Saved rules

Project rules live in `.claude/ppt-layout/rules/` in the user's project:

```
.claude/ppt-layout/rules/
├── README.md               <- copy of references/rules-readme.md
├── rule-assignments.md     <- from references/rule-assignments-template.md
└── <rule-name>.md          <- one file per named rule, from templates/rule-template.md
```

- **Save**: only on request. Create the directory if missing, copy the two reference
  files on first use, write `<rule-name>.md` from the template, and add a row to
  `rule-assignments.md`. Rule names are lowercase kebab-case and unique.
- **List**: read `rule-assignments.md` and present each rule with its scope, the
  slides it applies to, its tier, and its status.
- **Reuse**: a saved rule defines *what* to do; the assignments file defines *where*.
  The same rule can be assigned to different slides in different decks.
- **Edit / remove**: update the rule file and its assignment rows together. Never
  delete a rule file without the user asking.

Read `references/rules-readme.md` before the first save, list, edit, or remove
operation in a session.

## Invocation examples

```
/ppt-layout deck.pptx unify the title position, font size, and side margins
/ppt-layout make slides 3 to 8 two-column
/ppt-layout slide 5 is an exception: put the chart below the text
/ppt-layout make the images on slides 2, 4, and 6 the same size
/ppt-layout check the whole deck for text overflow, overlap, and off-slide objects
/ppt-layout save the title rule as a reusable rule
/ppt-layout list all rules and the slides each one applies to
```

Requests may be written in any language; reply in the user's language.
