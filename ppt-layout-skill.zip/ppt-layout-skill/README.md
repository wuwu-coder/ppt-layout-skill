# ppt-layout

A Claude Code skill for keeping PowerPoint (`.pptx`) layouts consistent. Describe
layout rules in plain language; Claude checks the deck, applies the rules, and verifies
the result.

## What it does

- Applies layout rules at three scopes: **whole deck**, **slide range** (inclusive),
  and **single slide**.
- Resolves conflicts with a fixed precedence:
  **single slide > slide range > deck-wide > existing layout defaults**. A more
  specific rule overrides only the properties it conflicts with; everything else from
  the broader rule still applies.
- Checks alignment, margins, spacing, typography, text overflow, overlap, off-slide
  objects, and consistency of repeated elements.
- Saves named rules for reuse under `.claude/ppt-layout/rules/`, with a table mapping
  each rule to the slides it applies to.
- Validates slide numbers and reports anything it could not check or modify instead
  of claiming it did.
- Preserves content: no deleted content, no changed chart data, facts, or citations.

## Installation

The skill directory must be named `ppt-layout` and contain `SKILL.md` at its top
level.

### Personal (available in all your projects)

macOS / Linux:

```bash
unzip ppt-layout-skill.zip
mkdir -p ~/.claude/skills
mv ppt-layout-skill ~/.claude/skills/ppt-layout
```

Windows (PowerShell):

```powershell
Expand-Archive ppt-layout-skill.zip -DestinationPath .
New-Item -ItemType Directory -Force "$env:USERPROFILE\.claude\skills" | Out-Null
Move-Item ppt-layout-skill "$env:USERPROFILE\.claude\skills\ppt-layout"
```

### Project (available only in one project)

Run from the project root.

macOS / Linux:

```bash
unzip ppt-layout-skill.zip
mkdir -p .claude/skills
mv ppt-layout-skill .claude/skills/ppt-layout
```

Windows (PowerShell):

```powershell
Expand-Archive ppt-layout-skill.zip -DestinationPath .
New-Item -ItemType Directory -Force ".claude\skills" | Out-Null
Move-Item ppt-layout-skill ".claude\skills\ppt-layout"
```

Start a new Claude Code session afterwards. `/ppt-layout` should appear in the slash
command menu.

### Requirements

To modify files, Claude needs a tool that can edit `.pptx`. The skill uses a dedicated
PowerPoint tool if the session has one, and otherwise `python-pptx`:

```bash
pip install python-pptx
```

Optional: LibreOffice, for rendering slides to images so that text overflow and visual
clarity can be verified rather than estimated. Without an editing tool the skill still
produces explicit rules and per-slide instructions, and states that nothing was
modified.

## Usage

Invoke it explicitly with `/ppt-layout`, or simply describe a PowerPoint layout task
and Claude will load the skill on its own.

```
/ppt-layout deck.pptx unify the title position, font size, and side margins across the deck
/ppt-layout make slides 3 to 8 two-column
/ppt-layout slide 5 is an exception: put the chart below the text
/ppt-layout make the images on slides 2, 4, and 6 the same size
/ppt-layout check the whole deck for text overflow, overlapping objects, and off-slide content
/ppt-layout save the title rule as a reusable rule
/ppt-layout list all rules and the slides each one applies to
```

Changes are written to a copy (`<name>.layout.pptx`) unless you ask to overwrite the
original.

### Precedence example

| Rule | Scope |
|------|-------|
| All titles left-aligned | Deck |
| Content uses a two-column layout | Slides 3-8 |
| Chart sits below the text | Slide 5 |

Slide 5 gets all three: a left-aligned title, the two-column layout, and the chart
below the text. The slide rule replaces only the chart placement.

### Saved rules

Rules are saved only when you ask. They are stored in your project:

```
.claude/ppt-layout/rules/
├── README.md               how rules are managed
├── rule-assignments.md     which rule applies to which slides of which deck
└── <rule-name>.md          one file per named rule
```

## Package contents

```
ppt-layout-skill/
├── README.md                              this file
├── SKILL.md                               skill instructions loaded by Claude Code
├── references/
│   ├── rules-readme.md                    rule management guide
│   └── rule-assignments-template.md       rule-to-slide mapping table
└── templates/
    └── rule-template.md                   template for a saved rule
```

## Limitations

- `python-pptx` does not render slides. Text overflow and line wrapping are estimated
  unless a renderer is available.
- SmartArt internals and embedded chart layouts cannot be inspected in detail.
- Saved range and single-slide rules refer to slide numbers. After adding, removing,
  or reordering slides, the skill asks you to confirm the numbers before applying them.
